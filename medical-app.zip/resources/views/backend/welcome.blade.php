@extends('backend.layout.main')
@section('body-part')
<div class="content-wrapper">
    <x-breadcumb title="Home"/>
    <div class="content">
        <div class="container-fluid">
            <div class="row">

            </div>
        </div>
    </div>
</div>
@endsection
