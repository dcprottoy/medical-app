<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Developed By Prottoy Khandakar
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024-2025 Alif Medical Centre .</strong> All rights reserved.
</footer>
