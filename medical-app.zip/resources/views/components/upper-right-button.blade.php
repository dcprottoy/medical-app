<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-12 text-right">
                <a class="btn btn-secondary btn-md" href="{{route($link)}}">
                    <i class="{{ $icon }}"></i>
                    {{$title}}
                </a>
            </div>
        </div>
    </div>
</div>
