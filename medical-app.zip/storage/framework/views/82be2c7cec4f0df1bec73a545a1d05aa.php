<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-12 text-right">
                <a class="btn btn-secondary btn-md" href="<?php echo e(route($link)); ?>">
                    <i class="<?php echo e($icon); ?>"></i>
                    <?php echo e($title); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\medical-app\resources\views/components/upper-right-button.blade.php ENDPATH**/ ?>