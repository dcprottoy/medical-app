<?php $__env->startSection('body-part'); ?>
<style>
.search-list{
    height:480px;
    overflow-x: hidden;
    overflow-y: scroll;
}
/*
.patient-select:hover{
    cursor: pointer;
    background-color: beige;
}
*/
@media print
{
body * { visibility: hidden; }
#print-div * { visibility: visible; }
#print-button { visibility: hidden; }
#print-buttons { visibility: hidden; }

#print-div { position: absolute; top: 40px; left: 30px; }
}
</style>
<div class="content-wrapper">
    <?php if (isset($component)) { $__componentOriginalfe64013587494d15808011b4de513329 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe64013587494d15808011b4de513329 = $attributes; } ?>
<?php $component = App\View\Components\Breadcumb::resolve(['title' => 'Appoinments'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe64013587494d15808011b4de513329)): ?>
<?php $attributes = $__attributesOriginalfe64013587494d15808011b4de513329; ?>
<?php unset($__attributesOriginalfe64013587494d15808011b4de513329); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe64013587494d15808011b4de513329)): ?>
<?php $component = $__componentOriginalfe64013587494d15808011b4de513329; ?>
<?php unset($__componentOriginalfe64013587494d15808011b4de513329); ?>
<?php endif; ?>
    <div class="content">
        <div class="container-fluid">
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">Appoinments Entry</h3>
                </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group text-center">
                                            <label><h4>Search Patient</h4></label>
                                            <input type="text" class="form-control form-control-sm" id="patient" name="patient" placeholder="Patient ID,Name,Contact No">
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <ul class="list-group search-list" id="patient_s_list">
                                            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item patient-select " data-id=<?php echo $patient->id; ?>>

                                                    <b>Patient ID :</b> <em><?php echo $patient->patient_id; ?></em><br>
                                                    <b>Name :</b> <?php echo $patient->name; ?><br>
                                                    <b>Contact No :</b> <?php echo $patient->contact_no; ?><br>
                                                    <b>Age :</b> <?php echo $patient->age; ?><br>
                                                    <button class="btn btn-sm btn-info patient_search_btn" style="width:50%;float:right;" data-id=<?php echo $patient->id; ?> >Select</button>

                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group  text-center">
                                            <label><h4>Search Doctor</h4></label>
                                            <input type="text" class="form-control form-control-sm" id="doctor" name="doctor" placeholder="Doctor ID,Name,Contact No" required>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <ul class="list-group  search-list " id="doctor_s_list">
                                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item doctor-select ">
                                                <b>Doctor ID :</b><em><?php echo $doctor->doctor_id; ?></em><br>
                                                <b>Name :</b> <?php echo $doctor->name; ?><br>
                                                <b>Department :</b> <?php echo $doctor->department->name_eng; ?><br>
                                                <b>Contact No :</b><?php echo $doctor->contact_no; ?> <br>
                                                <button class="btn btn-sm btn-info  doctor_select" data-id=<?php echo $doctor->id; ?> style="float: right;width:50%;">Select</button></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="row">
                                    <div class="form-group  col-lg-12 text-center">
                                        <label><h4>Date</h4></label>
                                        <div class="input-group date" id="appointment_date" data-target-input="nearest">
                                            <input type="text" class="form-control form-control-sm datetimepicker-input" data-target="#appointment_date" name="appointment_date"  id="appointment"/>
                                            <div class="input-group-append" data-target="#appointment_date" data-toggle="datetimepicker">
                                                <div class="input-group-text">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group text-center">
                                        <label><h4>Note</h4></label>
                                        <textarea class="form-control" rows="5" placeholder="Enter ..." id="note-field"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <?php $__currentLoopData = $appointmenttypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check m-2">
                                                <input class="form-check-input" type="radio" name="appointment_type_id" value="<?php echo e($apttype->id); ?>" required <?php echo e($apttype->name_eng === "Consultation"?"checked":""); ?>>
                                                <label class="form-check-label"><?php echo e($apttype->name_eng); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <button class="btn btn-md btn-success col-sm-12" id="save-appointment">Save</button>
                            </div>
                            <div class="col-sm-4" id="print-div">
                                <h4 class="text-center">Appointment Information</h4>
                                <ul class="list-group">
                                    <li class="list-group-item">Patient Information</li>
                                    <li class="list-group-item">Appointment No:<span id="appoint-no"></span></li>
                                    <li class="list-group-item"><b>Patient ID :</b> <em id="patient-id"></em><br><b>Name :</b> <span id="patient-name"></span><br><b>Contact No :</b> <span id="patient-contact"></span><br><b>Age :</b> <span id="patient-age"></span></li>
                                    <li class="list-group-item">Doctor Information</li>
                                    <li class="list-group-item"><b>Doctor ID :</b> <em id="doctor-id"></em><br><b>Name :</b><span id="doctor-name"></span><br><b>Degree :</b><span id="doctor-department"></span> <br><b>Contact No :</b><span id="doctor-contact"></span></li>
                                    <li class="list-group-item">Appointment Details</li>
                                    <li class="list-group-item"><b>Date :</b> <em id="appon-date"></em><br><b>Serial No :</b><span id="serial-no"></span><br><b>Note :</b><em id="note"> </li>
                                    <li class="list-group-item" id="print-buttons"><button class="btn btn-md btn-danger col-sm-12" id="print-button">Print</button></li>
                                </ul>

                            </div>

                        </div>
                    </div>

            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Patient</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body p-0" style = "min-height:500px;">
                    <table class="table table-sm table-striped projects">
                        <thead>
                            <tr>
                            <th style="width: 5%">
                                Patient ID
                            </th>
                            <th style="width: 30%" class="text-center">
                                Name
                            </th>
                            <th style="width: 15%" class="text-center">
                                Contact No
                            </th>
                            <th style="width: 15%" class="text-center">
                                Address
                            </th>
                            <th style="width: 15%" class="text-center">
                                Gender
                            </th>
                            <th style="width: 10%" class="text-center">
                                Age
                            </th>
                            <th class="text-center" style="width: 25%">
                                Action
                            </th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo $item->patient_id; ?>

                                </td>
                                <td class="text-center" style="font-weight:bold;">
                                <?php echo $item->name; ?>

                                </td>
                                <td  class="text-center">
                                    <?php echo $item->contact_no; ?>

                                </td>
                                <td  class="text-Left">
                                    <?php echo $item->address; ?>

                                </td>
                                <td  class="text-center">
                                    <?php echo $item->sex == 'M' ? '<span class="badge badge-success">Male</span>' :( $item->sex == 'F' ? '<span class="badge badge-info">Female</span>' : '<span class="badge badge-warning">Other</span>'); ?>

                                </td>
                                <td  class="text-center">
                                    <?php echo $item->age; ?>

                                </td>

                                <td class="project-actions text-center">
                                    <a class="btn btn-info btn-sm update" data-id="<?php echo e($item->id); ?>">
                                        <i style="font-size:10px;" class="fas fa-pencil-alt">
                                        </i>

                                    </a>
                                    
                                    <a class="btn btn-danger btn-sm delete" href="#" data-id="<?php echo e($item->id); ?>" data-toggle="modal" data-target="#modal-default">
                                        <i style="font-size:10px;" class="fas fa-trash">
                                        </i>

                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="m-3">
                    
                </div>
            </div>
            <div class="modal fade" id="modal-default-delete">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <form action="" method="post" id="delete-modal">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div class="modal-header">
                                <h4 class="modal-title">Delete Patient</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>One fine body&hellip;</p>
                                </div>
                                <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="modal-default-update">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <form action="" method="post" id="update-modal">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-header">
                                <h4 class="modal-title">Update Patient Information</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control form-control-sm" id='u-name' name='name' placeholder="Patients Name" required>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Contact No.</label>
                                                <input type="text" class="form-control form-control-sm" id='u-contact_no' name='contact_no' placeholder="Contact Number" required>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Emergency Contact No.</label>
                                                <input type="text" class="form-control form-control-sm" id='u-emr_cont_no' name='emr_cont_no' placeholder="Emergency Contact Number">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" class="form-control form-control-sm" id='u-address' name='address' placeholder="Address" required>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Age</label>
                                                <input type="text" class="form-control form-control-sm" name="age" id="u-age" placeholder="Age" required>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-6 d-flex">
                                            <div class="form-check m-2">
                                            <input class="form-check-input" type="radio" id="u-male" name="sex" value="M" required>
                                            <label class="form-check-label">Male</label>
                                            </div>
                                            <div class="form-check m-2">
                                            <input class="form-check-input" type="radio" name="sex" id="u-female" value="F">
                                            <label class="form-check-label">Female</label>
                                            </div>
                                            <div class="form-check m-2">
                                                <input class="form-check-input" type="radio" name="sex" id="u-other" value="O">
                                                <label class="form-check-label">Other</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer justify-content-between" id="up-pl">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-warning">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        $("#print-button").on('click',function(e){
            window.print();
        });
        $(".patient_search_btn").on('click',function(e){
           let id = $(this).attr('data-id');
           $('.patient-select').each(function(){
            $(this).css("background-color", "white");
           });
           $(this).parents('.list-group-item').first().css("background-color", "beige");
            patientSet(id);

        });
        function patientSet(id){
            $.ajax({
                    url: "<?php echo e(url('patients/')); ?>/"+id,
                    success: function (result) {
                        console.log(result);
                        $("#patient-id").text(result.patient_id);
                        $("#patient-name").text(result.name);
                        $("#patient-contact").text(result.contact_no);
                        $("#patient-age").text(result.age);
                        checkSerial();
                    }
                });
        }
        $("#patient").on('keyup',function(e){
            let ch_data = $("#patient").val();
            console.log(ch_data);
            $.ajax({
                    type: 'PUT',
                    dataType: "json",
                    url: "<?php echo e(url('patient')); ?>/",
                    data:{
                        'search':ch_data,
                        '_token': '<?php echo e(csrf_token()); ?>',
                    },
                    success: function (result) {
                        console.log(result);
                        let element = "";
                        result.forEach(x =>{
                            element += `<li class="list-group-item d-flex">
                                <span>
                                    <b>Patient ID :</b>
                                    <em>${x.patient_id}</em>
                                    <br>
                                    <b>Name :</b>
                                    ${x.name}
                                </span>
                                <span>
                                    <b>
                                    Contact No :
                                    </b>
                                    ${x.contact_no}
                                    <br>
                                    <b>Age :</b>
                                     ${x.age}
                                    <button class="btn btn-sm btn-warning patient_search_btn" data-id=${x.id} style="float: right">
                                            Select
                                    </button>
                                </span>
                            </li>`
                        });
                        $("#patient_s_list").empty();
                        $("#patient_s_list").append(element);
                        $(".patient_search_btn").on('click',function(e){
                            let id = $(this).attr('data-id');
                            patientSet(id);
                        });
                    }
                });
        });
        $(".doctor_select").on('click',function(e){
           let id = $(this).attr('data-id');
           $('.doctor-select').each(function(){
            $(this).css("background-color", "white");
           });
           $(this).parents('.doctor-select').first().css("background-color", "beige");
            doctorSet(id);
        });
        function doctorSet(id){
            $.ajax({
                    url: "<?php echo e(url('doctors/')); ?>/"+id,
                    success: function (result) {
                        console.log(result);
                        $("#doctor-id").text(result.doctor_id);
                        $("#doctor-name").text(result.name);
                        $("#doctor-department").text(result.department.name_eng);
                        $("#doctor-contact").text(result.contact_no);
                        checkSerial();
                    }
                });
        }
        $("#doctor").on('keyup',function(e){
            let ch_data = $("#doctor").val();
            console.log(ch_data);
            $.ajax({
                    type: 'PUT',
                    dataType: "json",
                    url: "<?php echo e(url('doctor')); ?>/",
                    data:{
                        'search':ch_data,
                        '_token': '<?php echo e(csrf_token()); ?>',
                    },
                    success: function (result) {
                        console.log(result);
                        let element = "";
                        result.forEach(x=>{
                            element += `<li class="list-group-item">
                            <b>Doctor ID :</b>
                             <em>${x.doctor_id}</em>
                             <br>
                             <b>Name :</b>
                             ${x.name}
                             <br>
                             <b>Degree :</b>
                              ${x.degree}<br>
                              <b>Contact No :</b>
                              ${x.contact_no}
                              <button class="btn btn-sm btn-warning doctor_select" style="float: right" data-id=${x.id}>
                                Select</button>
                                </li>`
                        })

                        $("#doctor_s_list").empty();
                        $("#doctor_s_list").append(element);
                        $(".doctor_select").on('click',function(e){
                            let id = $(this).attr('data-id');
                            doctorSet(id);
                        });
                    }
                });
        });
        $(function () {
            var currentDate = new Date();
            console.log(currentDate);
            $('#appointment_date').datetimepicker({
                format: 'YYYY-MM-DD',
                defaultDate:  currentDate
            });
        })
        $("#appointment_date").on("change.datetimepicker", ({date}) => {
             let  dateData = new Date(date);
             let Year = dateData.getFullYear();
             let Month = dateData.getMonth()+1 < 10 ? '0'+(dateData.getMonth()+1) :dateData.getMonth()+1;
             let Day = dateData.getDate() < 10 ? '0'+dateData.getDate() :dateData.getDate();

            $("#appon-date").text(Year+'-'+Month+'-'+Day);
            checkSerial();

        })
        $("#patient").on('keyup',function(e){
            let ch_data = $("#patient").val();
            console.log(ch_data);
            $.ajax({
                    type: 'PUT',
                    dataType: "json",
                    url: "<?php echo e(url('patient')); ?>/",
                    data:{
                        'search':ch_data,
                        '_token': '<?php echo e(csrf_token()); ?>',
                    },
                    success: function (result) {
                        console.log(result);
                        let element = "";
                        result.forEach(x =>{
                            element += `<li class="list-group-item d-flex">
                                <span>
                                    <b>Patient ID :</b>
                                    <em>${x.patient_id}</em>
                                    <br>
                                    <b>Name :</b>
                                    ${x.name}
                                </span>
                                <span>
                                    <b>
                                    Contact No :
                                    </b>
                                    ${x.contact_no}
                                    <br>
                                    <b>Age :</b>
                                     ${x.age}
                                    <button class="btn btn-sm btn-warning patient_search_btn" data-id=${x.id} style="float: right">
                                            Select
                                    </button>
                                </span>
                            </li>`
                        });
                        $("#patient_s_list").empty();
                        $("#patient_s_list").append(element);
                        $(".patient_search_btn").on('click',function(e){
                            let id = $(this).attr('data-id');
                            patientSet(id);
                        });
                    }
            });
        });

        $("#note-field").on('keyup',function(e){
            let note_data = $("#note-field").val();
            $("#note").text(note_data);
        });
        $("#save-appointment").on('click',function(e){
            let note_data = $("#note-field").val();
            let date =  $("#appointment").val();
            let doctor_id =  $("#doctor-id").text();
            let patient_id =  $("#patient-id").text();
            if(doctor_id && patient_id && date){
                console.log({note_data,date,doctor_id,patient_id});
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('appoinments')); ?>",
                    data: {
                            '_token':'<?php echo e(csrf_token()); ?>',
                            patient_id:patient_id,
                            doctor_id:doctor_id,
                            appointed_date:date,
                            note:note_data,
                        },
                    success: function(response) {
                        if("success" in response){
                            toastr.success('New Appointment Created');
                            $("#appoint-no").text(response.success.appoint_id);
                        }
                    },
                });

            }
        });
        function checkSerial(){
            let date =  $("#appointment").val();
            let doctor_id =  $("#doctor-id").text();
            let patient_id =  $("#patient-id").text();
            console.log({date,doctor_id,patient_id});

            if(doctor_id && patient_id && date){
                console.log({date,doctor_id,patient_id});
                $.ajax({
                    type:"POST",
                    url: "<?php echo e(url('appointment/checkserial')); ?>",
                    data:{
                        '_token':'<?php echo e(csrf_token()); ?>',
                            patient_id:patient_id,
                            doctor_id:doctor_id,
                            appointed_date:date,

                    },
                    success: function (result) {
                        if(result.message == "Already Appointed"){
                            toastr.warning('Already Appointed');
                            $("#serial-no").text(result.data.serial);
                            $("#appoint-no").text(result.data.appoint_id);
                            $("#note").text(result.data.note);
                        }else if(result.message == "New Serial No"){
                            $("#appoint-no").text("");
                            $("#serial-no").text(result.data);
                        }

                    }
                });

            }
        }


    });

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medical-app\resources\views/backend/appoinments/index.blade.php ENDPATH**/ ?>