<div class="content-header m-1 p-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6 text-right">
                <h4 class="m-0"><?php echo e($title); ?></h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right" style=" font-size:14px;">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                    <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\medical-app\resources\views/components/breadcumb.blade.php ENDPATH**/ ?>