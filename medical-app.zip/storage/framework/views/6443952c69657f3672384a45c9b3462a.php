<?php $__env->startSection('body-part'); ?>
<div class="content-wrapper">
    <?php if (isset($component)) { $__componentOriginalfe64013587494d15808011b4de513329 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe64013587494d15808011b4de513329 = $attributes; } ?>
<?php $component = App\View\Components\Breadcumb::resolve(['title' => 'Home'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe64013587494d15808011b4de513329)): ?>
<?php $attributes = $__attributesOriginalfe64013587494d15808011b4de513329; ?>
<?php unset($__attributesOriginalfe64013587494d15808011b4de513329); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe64013587494d15808011b4de513329)): ?>
<?php $component = $__componentOriginalfe64013587494d15808011b4de513329; ?>
<?php unset($__componentOriginalfe64013587494d15808011b4de513329); ?>
<?php endif; ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medical-app\resources\views/backend/welcome.blade.php ENDPATH**/ ?>